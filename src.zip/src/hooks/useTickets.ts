import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';
import { useParams } from 'react-router-dom';

export interface TicketType {
  id: string;
  name: string;
  price: number;
  currency: string;
  status: 'active' | 'expired' | 'draft';
  sold: number;
  total: number;
  revenue: number;
  isPro: boolean;
  endDate: string;
  startDate?: string;
  maxPerPerson: number;
  includes: string[];
  description?: string;
  event_id?: string;
  tier: 'standard' | 'vip';
}

export function useTickets() {
  const { eventId } = useParams<{ eventId: string }>();
  const [tickets, setTickets] = useState<TicketType[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (eventId) {
      loadTickets(eventId);
    }
  }, [eventId]);

  const loadTickets = async (id: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('event_tickets')
        .select('*')
        .eq('event_id', id)
      if (error) {
        if (error.code === 'PGRST204' || error.code === '42P01') {
          console.warn('event_tickets table not found');
          setTickets([]);
          return;
        }
        throw error;
      }

      // Map DB fields to UI fields
      const mappedTickets: TicketType[] = (data || []).map(t => ({
        id: t.id,
        name: t.name,
        price: t.price || 0,
        currency: 'USD', // Default to USD as per schema simplified
        status: (t.status as any) || 'active',
        sold: t.quantity_sold || 0,
        total: t.quantity_total || 0,
        revenue: (t.price || 0) * (t.quantity_sold || 0),
        isPro: t.is_vip,
        endDate: t.sales_end ? new Date(t.sales_end).toLocaleDateString() : '',
        startDate: t.sales_start ? new Date(t.sales_start).toLocaleDateString() : '',
        maxPerPerson: t.max_per_person || 10,
        includes: Array.isArray(t.includes) ? t.includes : [],
        description: t.description,
        event_id: t.event_id,
        tier: t.is_vip ? 'vip' : 'standard'
      }));

      setTickets(mappedTickets);
    } catch (error) {
      console.error('Error loading tickets:', error);
      toast.error('Failed to load tickets');
    } finally {
      setIsLoading(false);
    }
  };

  const createTicket = async (ticket: Partial<TicketType>) => {
    if (!eventId) return;
    try {
      const { data, error } = await supabase
        .from('event_tickets')
        .insert({
          event_id: eventId,
          name: ticket.name,
          price: ticket.price,
          quantity_total: ticket.total,
          sales_start: ticket.startDate ? new Date(ticket.startDate).toISOString() : null,
          sales_end: ticket.endDate ? new Date(ticket.endDate).toISOString() : null,
          status: 'active',
          includes: ticket.includes || [],
          is_vip: ticket.isPro || ticket.tier === 'vip',
          description: ticket.description,
          max_per_person: ticket.maxPerPerson,
          currency: ticket.currency
        })
        .select()
        .single();

      if (error) throw error;
      
      await loadTickets(eventId);
      toast.success('Ticket created');
      return data;
    } catch (error) {
      console.error('Error creating ticket:', error);
      toast.error('Failed to create ticket');
    }
  };

  const updateTicket = async (id: string, ticket: Partial<TicketType>) => {
    try {
      const { data, error } = await supabase
        .from('event_tickets')
        .update({
          name: ticket.name,
          price: ticket.price,
          quantity_total: ticket.total,
          sales_start: ticket.startDate ? new Date(ticket.startDate).toISOString() : null,
          sales_end: ticket.endDate ? new Date(ticket.endDate).toISOString() : null,
          status: ticket.status,
          includes: ticket.includes || [],
          is_vip: ticket.isPro || ticket.tier === 'vip',
          description: ticket.description,
          max_per_person: ticket.maxPerPerson,
          currency: ticket.currency
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      if (eventId) await loadTickets(eventId);
      toast.success('Ticket updated');
      return data;
    } catch (error) {
      console.error('Error updating ticket:', error);
      toast.error('Failed to update ticket');
    }
  };

  const deleteTicket = async (id: string) => {
    try {
      const { error } = await supabase
        .from('event_tickets')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      if (eventId) await loadTickets(eventId);
      toast.success('Ticket deleted');
    } catch (error) {
      console.error('Error deleting ticket:', error);
      toast.error('Failed to delete ticket');
    }
  };

  return {
    tickets,
    isLoading,
    createTicket,
    updateTicket,
    deleteTicket,
    loadTickets
  };
}
