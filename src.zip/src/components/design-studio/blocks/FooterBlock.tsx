import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin, Link2, Settings } from 'lucide-react';
import { useState } from 'react';
import EditModule from './EditModule';
import { useI18n } from '../../../i18n/I18nContext';

interface FooterBlockProps {
  showEditControls?: boolean;
  brandColor?: string;
  event?: {
    name?: string;
    tagline?: string;
    location_address?: string;
  };
}

export default function FooterBlock({ showEditControls = true, brandColor, event }: FooterBlockProps) {
  const { t, tList } = useI18n();
  const [isHovered, setIsHovered] = useState(false);
  const accentColor = brandColor || '#635BFF';
  const eventName = event?.name || t('wizard.designStudio.footer.eventName');
  const eventTagline = event?.tagline || t('wizard.designStudio.footer.tagline');
  const eventLocation = event?.location_address || t('wizard.designStudio.footer.location');
  const quickLinks = tList<string>('wizard.designStudio.footer.quickLinks', []);

  return (
    <div
      style={{ padding: '60px 40px', backgroundColor: '#1A1D1F', position: 'relative' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Edit Module */}
      {isHovered && showEditControls && (
        <EditModule
          blockName={t('wizard.designStudio.footer.blockName')}
          quickActions={[
            {
              icon: <Link2 size={16} style={{ color: '#FFFFFF' }} />,
              label: t('wizard.designStudio.footer.actions.socialLinks')
            },
            {
              icon: <Settings size={16} style={{ color: '#FFFFFF' }} />,
              label: t('wizard.designStudio.footer.actions.settings')
            }
          ]}
        />
      )}

      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Footer Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '48px',
            marginBottom: '48px'
          }}
        >
          {/* Column 1: Event Info */}
          <div>
            <div style={{ fontSize: '24px', fontWeight: 700, color: '#FFFFFF', marginBottom: '16px' }}>
              {eventName}
            </div>
            <p style={{ fontSize: '14px', color: 'rgba(255, 255, 255, 0.7)', marginBottom: '20px' }}>
              {eventTagline}
            </p>

            {/* Social Links */}
            <div style={{ display: 'flex', gap: '12px' }}>
              {[Facebook, Twitter, Linkedin, Instagram].map((Icon, idx) => (
                <button
                  key={idx}
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    border: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = accentColor;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                  }}
                >
                  <Icon size={18} style={{ color: '#FFFFFF' }} />
                </button>
              ))}
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#FFFFFF', marginBottom: '20px' }}>
              {t('wizard.designStudio.footer.quickLinksTitle')}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {quickLinks.map((link, idx) => (
                <a
                  key={idx}
                  href="#"
                  style={{
                    fontSize: '14px',
                    color: 'rgba(255, 255, 255, 0.7)',
                    textDecoration: 'none',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#FFFFFF';
                    e.currentTarget.style.textDecoration = 'underline';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = 'rgba(255, 255, 255, 0.7)';
                    e.currentTarget.style.textDecoration = 'none';
                  }}
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Column 3: Contact Info */}
          <div>
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#FFFFFF', marginBottom: '20px' }}>
              {t('wizard.designStudio.footer.contactTitle')}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {[
                { icon: Mail, text: t('wizard.designStudio.footer.contact.email') },
                { icon: Phone, text: t('wizard.designStudio.footer.contact.phone') },
                { icon: MapPin, text: eventLocation }
              ].map((contact, idx) => {
                const Icon = contact.icon;
                return (
                  <div key={idx} style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                    <Icon size={20} style={{ color: 'rgba(255, 255, 255, 0.5)', flexShrink: 0 }} />
                    <div style={{ fontSize: '14px', color: 'rgba(255, 255, 255, 0.7)' }}>
                      {contact.text}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div
          style={{
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            paddingTop: '32px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '16px'
          }}
          >
          <div style={{ fontSize: '13px', color: 'rgba(255, 255, 255, 0.5)' }}>
            {t('wizard.designStudio.footer.copyright')}
          </div>
          <div style={{ fontSize: '13px', color: 'rgba(255, 255, 255, 0.5)' }}>
            {t('wizard.designStudio.footer.poweredBy')}{' '}
            <a
              href="#"
              style={{
                color: accentColor,
                textDecoration: 'none',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = accentColor;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = accentColor;
              }}
            >
              {t('wizard.designStudio.footer.brandName')}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
