import { X, CheckCircle, Plus, XCircle } from 'lucide-react';
import { useState } from 'react';

interface CustomField {
  id: string;
  type: 'text' | 'textarea' | 'dropdown' | 'checkbox' | 'radio' | 'date' | 'file' | 'number' | 'multichoice' | 'country' | 'email' | 'phone' | 'url' | 'address';
  label: string;
  placeholder?: string;
  helpText?: string;
  required: boolean;
  options?: string[];
  isPro: boolean;
}

interface FieldEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (field: CustomField) => void;
  onDelete: () => void;
  field: CustomField;
}

export default function FieldEditorModal({ isOpen, onClose, onSave, onDelete, field }: FieldEditorModalProps) {
  const [formData, setFormData] = useState<CustomField>(field);
  const [charCount, setCharCount] = useState(field.label.length);
  const [newOption, setNewOption] = useState('');

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(formData);
    onClose();
  };

  const handleLabelChange = (value: string) => {
    if (value.length <= 100) {
      setFormData({ ...formData, label: value });
      setCharCount(value.length);
    }
  };

  const handleAddOption = () => {
    if (newOption.trim()) {
      setFormData({
        ...formData,
        options: [...(formData.options || []), newOption.trim()]
      });
      setNewOption('');
    }
  };

  const handleRemoveOption = (index: number) => {
    setFormData({
      ...formData,
      options: formData.options?.filter((_, i) => i !== index)
    });
  };

  const handleUpdateOption = (index: number, value: string) => {
    setFormData({
      ...formData,
      options: formData.options?.map((opt, i) => i === index ? value : opt)
    });
  };

  const needsOptions = ['dropdown', 'radio', 'multichoice'].includes(formData.type);
  const supportsPlaceholder = ['text', 'textarea', 'number', 'email', 'phone', 'url'].includes(formData.type);

  const getFieldTypeName = () => {
    const names: Record<string, string> = {
      text: 'Single Line Text',
      textarea: 'Multi-line Text',
      dropdown: 'Dropdown Select',
      checkbox: 'Checkbox',
      radio: 'Radio Buttons',
      date: 'Date Picker',
      file: 'File Upload',
      number: 'Number Input',
      multichoice: 'Multiple Choice',
      country: 'Country Selector',
      email: 'Email Input',
      phone: 'Phone Number Input',
      url: 'URL Input',
      address: 'Address Input'
    };
    return names[formData.type] || formData.type;
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ backgroundColor: 'rgba(11, 38, 65, 0.7)' }}
        onClick={onClose}
      >
        {/* Modal */}
        <div 
          className="w-[600px] rounded-xl overflow-hidden"
          style={{ 
            backgroundColor: '#FFFFFF',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
            maxHeight: '85vh',
            display: 'flex',
            flexDirection: 'column'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div 
            className="p-6"
            style={{ borderBottom: '1px solid #E5E7EB' }}
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 
                  className="text-xl mb-1"
                  style={{ fontWeight: 600, color: '#0B2641' }}
                >
                  Edit Field
                </h2>
                <span 
                  className="inline-block px-2 py-1 rounded text-xs"
                  style={{ backgroundColor: '#F3F4F6', color: '#6B7280', fontWeight: 600 }}
                >
                  {getFieldTypeName()}
                </span>
              </div>
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-colors hover:bg-gray-100"
                style={{ color: '#6B7280' }}
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Content - Scrollable */}
          <div 
            className="flex-1 overflow-y-auto p-6"
            style={{ maxHeight: 'calc(85vh - 180px)' }}
          >
            <div className="space-y-5">
              {/* Field Label */}
              <div>
                <label 
                  className="block text-sm mb-2"
                  style={{ fontWeight: 500, color: '#0B2641' }}
                >
                  Field Label *
                </label>
                <input
                  type="text"
                  value={formData.label}
                  onChange={(e) => handleLabelChange(e.target.value)}
                  placeholder="e.g., Company Name"
                  className="w-full h-11 px-4 rounded-lg border outline-none transition-colors focus:border-blue-400"
                  style={{ 
                    borderColor: '#E5E7EB',
                    color: '#0B2641',
                    backgroundColor: '#FFFFFF'
                  }}
                />
                <div className="flex justify-end mt-1">
                  <span 
                    className="text-xs"
                    style={{ color: charCount > 90 ? '#EF4444' : '#9CA3AF' }}
                  >
                    {charCount}/100
                  </span>
                </div>
              </div>

              {/* Help Text */}
              <div>
                <label 
                  className="block text-sm mb-2"
                  style={{ fontWeight: 500, color: '#0B2641' }}
                >
                  Help Text (Optional)
                </label>
                <input
                  type="text"
                  value={formData.helpText || ''}
                  onChange={(e) => setFormData({ ...formData, helpText: e.target.value })}
                  placeholder="Add instructions or examples"
                  className="w-full h-11 px-4 rounded-lg border outline-none transition-colors focus:border-blue-400"
                  style={{ 
                    borderColor: '#E5E7EB',
                    color: '#0B2641',
                    backgroundColor: '#FFFFFF'
                  }}
                />
              </div>

              {/* Placeholder (for applicable field types) */}
              {supportsPlaceholder && (
                <div>
                  <label 
                    className="block text-sm mb-2"
                    style={{ fontWeight: 500, color: '#0B2641' }}
                  >
                    Placeholder
                  </label>
                  <input
                    type="text"
                    value={formData.placeholder || ''}
                    onChange={(e) => setFormData({ ...formData, placeholder: e.target.value })}
                    placeholder="e.g., Enter your company"
                    className="w-full h-11 px-4 rounded-lg border outline-none transition-colors focus:border-blue-400"
                    style={{ 
                      borderColor: '#E5E7EB',
                      color: '#0B2641',
                      backgroundColor: '#FFFFFF'
                    }}
                  />
                </div>
              )}

              {/* Field Options (for dropdown, radio, multichoice) */}
              {needsOptions && (
                <div>
                  <label 
                    className="block text-sm mb-2"
                    style={{ fontWeight: 500, color: '#0B2641' }}
                  >
                    Options
                  </label>
                  
                  {/* Existing Options */}
                  <div className="space-y-2 mb-3">
                    {formData.options?.map((option, index) => (
                      <div key={index} className="flex gap-2">
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => handleUpdateOption(index, e.target.value)}
                          className="flex-1 h-10 px-4 rounded-lg border outline-none transition-colors focus:border-blue-400"
                          style={{ 
                            borderColor: '#E5E7EB',
                            color: '#0B2641',
                            backgroundColor: '#FFFFFF'
                          }}
                        />
                        <button
                          onClick={() => handleRemoveOption(index)}
                          className="w-10 h-10 rounded-lg flex items-center justify-center transition-colors hover:bg-red-50"
                        >
                          <XCircle size={18} style={{ color: '#EF4444' }} />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Add New Option */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newOption}
                      onChange={(e) => setNewOption(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddOption()}
                      placeholder="Add new option"
                      className="flex-1 h-10 px-4 rounded-lg border outline-none transition-colors focus:border-blue-400"
                      style={{ 
                        borderColor: '#E5E7EB',
                        color: '#0B2641',
                        backgroundColor: '#FFFFFF'
                      }}
                    />
                    <button
                      onClick={handleAddOption}
                      className="w-10 h-10 rounded-lg border flex items-center justify-center transition-colors hover:bg-blue-50"
                      style={{ borderColor: '#E5E7EB' }}
                    >
                      <Plus size={18} style={{ color: 'var(--primary)' }} />
                    </button>
                  </div>
                </div>
              )}

              {/* Validation Rules */}
              <div>
                <label 
                  className="block text-sm mb-3"
                  style={{ fontWeight: 500, color: '#0B2641' }}
                >
                  Validation Rules
                </label>
                
                <div className="space-y-3">
                  {/* Make Required */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm" style={{ color: '#0B2641' }}>
                      Make this field required
                    </span>
                    <button
                      onClick={() => setFormData({ ...formData, required: !formData.required })}
                      className="relative w-11 h-6 rounded-full transition-colors"
                      style={{ 
                        backgroundColor: formData.required ? 'var(--primary)' : '#E5E7EB'
                      }}
                    >
                      <div
                        className="absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform"
                        style={{
                          left: formData.required ? 'calc(100% - 22px)' : '2px'
                        }}
                      />
                    </button>
                  </div>

                  {/* Validate Input Format (for text fields) */}
                  {formData.type === 'text' && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm" style={{ color: '#0B2641' }}>
                          Validate input format
                        </span>
                        <button
                          className="relative w-11 h-6 rounded-full"
                          style={{ backgroundColor: '#E5E7EB' }}
                        >
                          <div
                            className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full"
                          />
                        </button>
                      </div>
                      <select
                        className="w-full h-10 px-4 rounded-lg border outline-none cursor-pointer"
                        style={{ 
                          borderColor: '#E5E7EB',
                          color: '#0B2641',
                          backgroundColor: '#FFFFFF'
                        }}
                      >
                        <option value="none">None</option>
                        <option value="email">Email</option>
                        <option value="url">URL</option>
                        <option value="phone">Phone Number</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>

              {/* Field Width */}
              <div>
                <label 
                  className="block text-sm mb-3"
                  style={{ fontWeight: 500, color: '#0B2641' }}
                >
                  Field Width
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { value: 'full', label: 'Full Width' },
                    { value: 'half', label: 'Half Width' }
                  ].map((option) => (
                    <button
                      key={option.value}
                      className="h-10 rounded-lg border transition-colors hover:border-blue-400"
                      style={{
                        borderColor: '#E5E7EB',
                        backgroundColor: '#FFFFFF',
                        color: '#0B2641',
                        fontWeight: 500
                      }}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div 
            className="flex items-center justify-between p-6"
            style={{ borderTop: '1px solid #E5E7EB' }}
          >
            <button
              onClick={onDelete}
              className="text-sm transition-colors hover:underline"
              style={{ color: '#EF4444', fontWeight: 500 }}
            >
              Delete Field
            </button>
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="h-11 px-5 rounded-lg transition-colors hover:bg-gray-100"
                style={{ color: '#0B2641', fontWeight: 600 }}
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="h-11 px-5 rounded-lg flex items-center gap-2 transition-all hover:scale-105"
                style={{ 
                  backgroundColor: 'var(--primary)',
                  color: '#FFFFFF',
                  fontWeight: 600
                }}
              >
                <CheckCircle size={18} />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}