import { useState } from 'react';
import {
  Users,
  Star,
  Calendar,
  Plus,
  Grid3x3,
  List,
  Search,
  Filter,
  ChevronDown,
  Edit2,
  Eye,
  MoreVertical,
  Mail,
  Trash2,
  Download
} from 'lucide-react';
import AddEditSpeakerModal from './modals/AddEditSpeakerModal';
import SpeakerProfileModal from './modals/SpeakerProfileModal';
import ImportSpeakersModal from './modals/ImportSpeakersModal';
import SuccessToast from './SuccessToast';
import { useSpeakers, Speaker } from '../../hooks/useSpeakers';
import { useI18n } from '../../i18n/I18nContext';

export default function SpeakersTab() {
  const { speakers, isLoading, createSpeaker, updateSpeaker, deleteSpeaker } = useSpeakers();
  const { t } = useI18n();

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeFilter, setActiveFilter] = useState<'all' | 'keynote' | 'panel' | 'workshop'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [editingSpeaker, setEditingSpeaker] = useState<Speaker | null>(null);
  const [viewingSpeaker, setViewingSpeaker] = useState<Speaker | null>(null);
  const [selectedSpeakers, setSelectedSpeakers] = useState<Set<string>>(new Set());
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [deletingSpeaker, setDeletingSpeaker] = useState<string | null>(null);

  const handleSelectSpeaker = (id: string) => {
    const newSelected = new Set(selectedSpeakers);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedSpeakers(newSelected);
  };

  const handleEditSpeaker = (speaker: Speaker) => {
    setEditingSpeaker(speaker);
    setIsAddModalOpen(true);
  };

  const handleViewProfile = (speaker: Speaker) => {
    setViewingSpeaker(speaker);
    setIsProfileModalOpen(true);
  };

  const handleSaveSpeaker = async (data: any) => {
    // Map form data to Speaker type
    // The modal likely returns a form object. We need to align it with Supabase schema.
    const payload: Partial<Speaker> = {
      full_name: data.name,
      title: data.title,
      company: data.company,
      bio: data.bio,
      photo: data.photo,
      linkedin_url: data.linkedin,
      twitter_url: data.twitter,
      website_url: data.website,
      phone: data.phone,
      email: data.email,
      type: data.type,
      status: data.status,
      tags: data.tags
    };

    if (editingSpeaker?.id) {
      await updateSpeaker(editingSpeaker.id, payload);
      setToastMessage(t('wizard.step3.speakers.toasts.updated'));
    } else {
      await createSpeaker(payload);
      setToastMessage(t('wizard.step3.speakers.toasts.created'));
    }

    setShowToast(true);
    setEditingSpeaker(null);
    setIsAddModalOpen(false);
  };

  const handleDeleteSpeaker = async (id: string) => {
      if(confirm("Are you sure you want to delete this speaker?")) {
        await deleteSpeaker(id);
        setToastMessage("Speaker deleted successfully");
        setShowToast(true);
      }
      setDeletingSpeaker(null);
  };

  const getTypeBadge = (type: string) => {
    const badges = {
      keynote: { label: 'KEYNOTE', bg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', icon: Star },
      panel: { label: 'PANEL', bg: '#0684F5', icon: Users },
      workshop: { label: 'WORKSHOP', bg: '#8B5CF6', icon: Calendar },
      regular: null
    };
    return badges[type as keyof typeof badges] || badges.regular;
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      confirmed: { label: 'Confirmed', color: 'var(--success)' },
      pending: { label: 'Pending', color: '#F59E0B' },
      declined: { label: 'Declined', color: '#EF4444' }
    };
    return badges[status as keyof typeof badges] || badges.pending;
  };

  const filteredSpeakers = speakers.filter(speaker => {
    if (activeFilter === 'all') return true;
    return speaker.type === activeFilter;
  });

  return (
    <div 
      className="speakers-container mx-auto"
      style={{ 
        backgroundColor: '#0B2641',
        maxWidth: '1200px',
        padding: '40px 40px 80px 40px',
        minHeight: 'calc(100vh - 300px)'
      }}
    >
      <style>{`
        @media (max-width: 1024px) {
          .speakers-container { padding: 1rem !important; }
          .speakers-header { flex-direction: column !important; gap: 1rem !important; }
          .speakers-header-actions { width: 100% !important; }
          .speakers-add-btn { flex: 1 !important; justify-content: center !important; }
          .speakers-filter-bar { flex-direction: column !important; align-items: stretch !important; gap: 1rem !important; }
          .speakers-filter-tabs { overflow-x: auto !important; padding-bottom: 0.5rem !important; }
          .speakers-filter-tabs button { white-space: nowrap !important; }
          .speakers-search-controls { flex-direction: column !important; width: 100% !important; }
          .speakers-search-wrapper { width: 100% !important; }
          .speakers-other-controls { width: 100% !important; }
          .speakers-other-controls button { flex: 1 !important; }
          .speakers-grid { grid-template-columns: 1fr !important; }
          .speaker-list-view { overflow-x: auto !important; }
          .speaker-list-inner { min-width: 800px !important; }
          .speaker-bulk-bar { flex-direction: column !important; gap: 1rem !important; }
          .speaker-bulk-actions { width: 100% !important; justify-content: center !important; flex-wrap: wrap !important; }
          .speaker-bulk-btn { flex: 1 1 auto !important; min-width: 120px !important; justify-content: center !important; }
        }
        @media (max-width: 500px) {
          .speakers-container { padding: 0.5rem !important; }
          .speakers-grid { gap: 1rem !important; }
        }
      `}</style>
      {/* PAGE HEADER */}
      <div className="speakers-header flex items-start justify-between mb-8">
        <div>
          <h2 className="text-3xl mb-2" style={{ fontWeight: 600, color: '#FFFFFF' }}>
            Speakers & Presenters
          </h2>
          <p className="text-base" style={{ color: '#94A3B8' }}>
            Manage your event's speakers and their profiles
          </p>
        </div>
        <div className="speakers-header-actions flex items-center gap-3">
          {/* View Toggle */}
          <div className="flex items-center gap-0 p-1 rounded-lg" style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <button
              onClick={() => setViewMode('grid')}
              className="w-10 h-10 rounded flex items-center justify-center transition-colors"
              style={{
                backgroundColor: viewMode === 'grid' ? '#0684F5' : 'transparent',
                color: viewMode === 'grid' ? '#FFFFFF' : '#94A3B8'
              }}
            >
              <Grid3x3 size={18} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className="w-10 h-10 rounded flex items-center justify-center transition-colors"
              style={{
                backgroundColor: viewMode === 'list' ? '#0684F5' : 'transparent',
                color: viewMode === 'list' ? '#FFFFFF' : '#94A3B8'
              }}
            >
              <List size={18} />
            </button>
          </div>
          
          {/* Add Speaker Button */}
          <button
            onClick={() => {
              setEditingSpeaker(null);
              setIsAddModalOpen(true);
            }}
            className="speakers-add-btn flex items-center gap-2 px-5 h-11 rounded-lg transition-transform hover:scale-105"
            style={{ backgroundColor: 'var(--primary)', color: '#FFFFFF', fontWeight: 600 }}
          >
            <Plus size={18} />
            Add Speaker
          </button>
        </div>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="speakers-filter-bar flex items-center justify-between mb-6">
        {/* Filter Tabs */}
        <div className="speakers-filter-tabs flex items-center gap-2">
          {[
            { id: 'all', label: 'All Speakers' },
            { id: 'keynote', label: 'Keynote' },
            { id: 'panel', label: 'Panel' },
            { id: 'workshop', label: 'Workshop' }
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id as any)}
              className="px-5 py-2.5 rounded-lg transition-colors"
              style={{
                backgroundColor: activeFilter === filter.id ? 'var(--primary)' : 'transparent',
                color: activeFilter === filter.id ? '#FFFFFF' : '#6B7280',
                fontWeight: 600
              }}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Search & Controls */}
        <div className="speakers-search-controls flex items-center gap-3">
          {/* Search Input */}
          <div className="speakers-search-wrapper relative" style={{ width: '320px' }}>
            <Search 
              size={18} 
              style={{ 
                position: 'absolute',
                left: '12px',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#9CA3AF'
              }}
            />
            <input
              type="text"
              placeholder="Search speakers..."
              className="w-full h-11 pl-10 pr-4 rounded-lg border outline-none"
              style={{ 
                borderColor: '#E5E7EB',
                backgroundColor: '#FFFFFF',
                color: '#0B2641'
              }}
            />
          </div>

          <div className="speakers-other-controls flex items-center gap-3">
            {/* Filter Button */}
            <button className="w-11 h-11 rounded-lg border flex items-center justify-center transition-colors hover:bg-gray-50">
                <Filter size={18} style={{ color: '#6B7280' }} />
            </button>

            {/* Sort Dropdown */}
            <button className="flex items-center gap-2 px-4 h-11 rounded-lg border transition-colors hover:bg-gray-50">
                <span style={{ color: '#6B7280', fontWeight: 500 }}>Sort by: Name</span>
                <ChevronDown size={16} style={{ color: '#6B7280' }} />
            </button>
          </div>
        </div>
      </div>

      {/* SPEAKERS GRID VIEW */}
      {viewMode === 'grid' && (
        <div className="speakers-grid grid grid-cols-3 gap-6">
          {filteredSpeakers.map((speaker) => {
            const badge = getTypeBadge(speaker.type);
            const statusBadge = getStatusBadge(speaker.status);

            return (
              <div
                key={speaker.id}
                className="rounded-xl overflow-hidden border transition-all hover:shadow-lg"
                style={{ 
                  backgroundColor: '#FFFFFF',
                  borderColor: '#E5E7EB',
                  transform: 'translateY(0)',
                  transition: 'transform 0.2s, box-shadow 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                {/* Header Image Section */}
                <div 
                  className="relative flex items-center justify-center"
                  style={{ 
                    height: '180px',
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  }}
                >
                  {/* Profile Photo */}
                  <div 
                    className="w-[120px] h-[120px] rounded-full flex items-center justify-center"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      border: '4px solid #FFFFFF',
                      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                    }}
                  >
                    {speaker.photo ? (
                        <img src={speaker.photo} alt={speaker.full_name} className="w-full h-full object-cover" />
                    ) : (
                        <Users size={48} style={{ color: '#9CA3AF' }} />
                    )}
                  </div>

                  {/* Type Badge */}
                  {badge && (
                    <div 
                      className="absolute top-2 right-2 flex items-center gap-1 px-3 py-1.5 rounded-xl"
                      style={{ 
                        background: badge.bg,
                        color: '#FFFFFF',
                        fontWeight: 700,
                        fontSize: '11px',
                        letterSpacing: '0.5px'
                      }}
                    >
                      <badge.icon size={12} />
                      {badge.label}
                    </div>
                  )}
                </div>

                {/* Content Section */}
                <div className="p-5">
                  {/* Name & Title */}
                  <div className="mb-2">
                    <h3 className="text-xl mb-1" style={{ fontWeight: 600, color: '#0B2641' }}>
                      {speaker.name}
                    </h3>
                    <p className="text-sm" style={{ color: '#6B7280' }}>{speaker.title}</p>
                    <p className="text-sm" style={{ color: '#6B7280' }}>{speaker.company}</p>
                  </div>

                  {/* Email */}
                  <div className="flex items-center gap-2 mb-3">
                    <Mail size={14} style={{ color: '#9CA3AF' }} />
                    <span className="text-xs" style={{ color: '#6B7280' }}>
                      {speaker.email}
                    </span>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mt-3">
                    {speaker.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 rounded-full text-xs"
                        style={{ 
                          backgroundColor: 'rgba(6, 132, 245, 0.1)',
                          color: 'var(--primary)',
                          fontWeight: 500
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Delete Button - Top Right */}
                  <button
                    onClick={() => setDeletingSpeaker(speaker.id)}
                    className="absolute top-2 left-2 w-9 h-9 rounded-lg flex items-center justify-center transition-colors z-10"
                    style={{ 
                      backgroundColor: 'rgba(239, 68, 68, 0.9)',
                      color: '#FFFFFF'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#EF4444'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(239, 68, 68, 0.9)'}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                {/* Footer Actions */}
                <div 
                  className="flex items-center justify-between p-5"
                  style={{ borderTop: '1px solid #E5E7EB' }}
                >
                  {/* Status Badge */}
                  <span 
                    className="px-3 py-1 rounded-full text-xs flex items-center gap-1.5"
                    style={{ 
                      backgroundColor: `${statusBadge.color}15`,
                      color: statusBadge.color,
                      fontWeight: 600
                    }}
                  >
                    <div 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: statusBadge.color }}
                    />
                    {statusBadge.label}
                  </span>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleEditSpeaker(speaker)}
                      className="w-8 h-8 rounded flex items-center justify-center transition-colors hover:bg-gray-100"
                    >
                      <Edit2 size={14} style={{ color: '#6B7280' }} />
                    </button>
                    <button
                      onClick={() => handleViewProfile(speaker)}
                      className="w-8 h-8 rounded flex items-center justify-center transition-colors hover:bg-gray-100"
                    >
                      <Eye size={14} style={{ color: '#6B7280' }} />
                    </button>
                    <button className="w-8 h-8 rounded flex items-center justify-center transition-colors hover:bg-gray-100">
                      <MoreVertical size={14} style={{ color: '#6B7280' }} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Empty State Card */}
          <div
            className="rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-center p-8 transition-colors hover:border-blue-400 hover:bg-blue-50 cursor-pointer"
            style={{ 
              borderColor: '#E5E7EB',
              backgroundColor: '#FAFAFA',
              minHeight: '420px'
            }}
            onClick={() => {
              setEditingSpeaker(null);
              setIsAddModalOpen(true);
            }}
          >
            <Plus size={64} style={{ color: '#D1D5DB', marginBottom: '16px' }} />
            <h3 className="text-lg mb-2" style={{ fontWeight: 600, color: '#0B2641' }}>
              Add New Speaker
            </h3>
            <p className="text-sm mb-4" style={{ color: '#6B7280' }}>
              Build your speaker lineup
            </p>
            <button 
              className="px-5 h-10 rounded-lg border transition-colors hover:bg-white"
              style={{ borderColor: '#E5E7EB', fontWeight: 600 }}
            >
              + Add Speaker
            </button>
          </div>
        </div>
      )}

      {/* SPEAKERS LIST VIEW */}
      {viewMode === 'list' && (
        <div className="speaker-list-view rounded-xl overflow-hidden border" style={{ backgroundColor: '#FFFFFF', borderColor: '#E5E7EB' }}>
          <div className="speaker-list-inner">
            {/* Table Header */}
            <div 
              className="grid grid-cols-12 gap-4 p-4"
              style={{ backgroundColor: '#F9FAFB', borderBottom: '1px solid #E5E7EB' }}
            >
              <div className="col-span-1 flex items-center">
                <input type="checkbox" className="w-5 h-5" style={{ accentColor: 'var(--primary)' }} />
              </div>
              <div className="col-span-4">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Speaker</span>
              </div>
              <div className="col-span-3">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Title & Company</span>
              </div>
              <div className="col-span-1">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Sessions</span>
              </div>
              <div className="col-span-1">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Status</span>
              </div>
              <div className="col-span-1">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Type</span>
              </div>
              <div className="col-span-1 text-right">
                <span className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>Actions</span>
              </div>
            </div>

            {/* Table Rows */}
            {filteredSpeakers.map((speaker) => {
              const badge = getTypeBadge(speaker.type);
              const statusBadge = getStatusBadge(speaker.status);

              return (
                <div
                  key={speaker.id}
                  className="grid grid-cols-12 gap-4 p-4 transition-colors hover:bg-gray-50"
                  style={{ borderBottom: '1px solid #E5E7EB' }}
                >
                  <div className="col-span-1 flex items-center">
                    <input 
                      type="checkbox"
                      checked={selectedSpeakers.has(speaker.id)}
                      onChange={() => handleSelectSpeaker(speaker.id)}
                      className="w-5 h-5"
                      style={{ accentColor: 'var(--primary)' }}
                    />
                  </div>
                  <div className="col-span-4 flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-full flex items-center justify-center overflow-hidden"
                      style={{ backgroundColor: '#F3F4F6' }}
                    >
                      {speaker.photo ? (
                          <img src={speaker.photo} alt={speaker.full_name} className="w-full h-full object-cover" />
                      ) : (
                          <Users size={20} style={{ color: '#9CA3AF' }} />
                      )}
                    </div>
                    <div>
                      <p className="text-sm" style={{ fontWeight: 600, color: '#0B2641' }}>{speaker.full_name}</p>
                      <p className="text-xs" style={{ color: '#6B7280' }}>{speaker.email}</p>
                    </div>
                  </div>
                  <div className="col-span-3 flex items-center">
                    <p className="text-sm" style={{ color: '#6B7280' }}>
                      {speaker.title}, {speaker.company}
                    </p>
                  </div>
                  <div className="col-span-1 flex items-center">
                    <p className="text-sm" style={{ color: '#0B2641' }}>{speaker.sessions}</p>
                  </div>
                  <div className="col-span-1 flex items-center">
                    <span 
                      className="px-2 py-1 rounded-full text-xs flex items-center gap-1"
                      style={{ 
                        backgroundColor: `${statusBadge.color}15`,
                        color: statusBadge.color,
                        fontWeight: 600
                      }}
                    >
                      <div 
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ backgroundColor: statusBadge.color }}
                      />
                      {statusBadge.label}
                    </span>
                  </div>
                  <div className="col-span-1 flex items-center">
                    {badge && (
                      <span 
                        className="px-2 py-1 rounded text-xs"
                        style={{ 
                          background: badge.bg,
                          color: '#FFFFFF',
                          fontWeight: 600
                        }}
                      >
                        {badge.label}
                      </span>
                    )}
                  </div>
                  <div className="col-span-1 flex items-center justify-end">
                    <button className="w-8 h-8 rounded flex items-center justify-center transition-colors hover:bg-gray-200">
                      <MoreVertical size={16} style={{ color: '#6B7280' }} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* BULK ACTIONS BAR */}
      {selectedSpeakers.size > 0 && (
        <div 
          className="speaker-bulk-bar fixed bottom-0 left-0 right-0 p-4 flex items-center justify-between shadow-lg"
          style={{ 
            backgroundColor: '#FFFFFF',
            borderTop: '1px solid #E5E7EB',
            zIndex: 50
          }}
        >
          <div className="flex items-center gap-3">
            <span className="text-sm" style={{ color: '#0B2641', fontWeight: 500 }}>
              {selectedSpeakers.size} speakers selected
            </span>
            <button
              onClick={() => setSelectedSpeakers(new Set())}
              className="text-xs transition-colors hover:underline"
              style={{ color: 'var(--primary)', fontWeight: 600 }}
            >
              Deselect All
            </button>
          </div>
          <div className="speaker-bulk-actions flex items-center gap-2">
            <button className="speaker-bulk-btn flex items-center gap-2 px-4 h-9 rounded-lg transition-colors hover:bg-gray-50">
              <Download size={16} style={{ color: '#6B7280' }} />
              <span className="text-sm" style={{ color: '#6B7280', fontWeight: 600 }}>Export</span>
            </button>
            <button className="speaker-bulk-btn flex items-center gap-2 px-4 h-9 rounded-lg transition-colors hover:bg-gray-50">
              <Mail size={16} style={{ color: '#6B7280' }} />
              <span className="text-sm" style={{ color: '#6B7280', fontWeight: 600 }}>Send Message</span>
            </button>
            <button className="speaker-bulk-btn flex items-center gap-2 px-4 h-9 rounded-lg transition-colors hover:bg-red-50">
              <Trash2 size={16} style={{ color: '#EF4444' }} />
              <span className="text-sm" style={{ color: '#EF4444', fontWeight: 600 }}>Delete</span>
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      <AddEditSpeakerModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingSpeaker(null);
        }}
        onSave={handleSaveSpeaker}
        speaker={editingSpeaker}
      />

      <SpeakerProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => {
          setIsProfileModalOpen(false);
          setViewingSpeaker(null);
        }}
        speaker={viewingSpeaker}
      />

      <ImportSpeakersModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={(data) => {
          setToastMessage('Speakers imported successfully');
          setShowToast(true);
        }}
      />

      {/* Toast */}
      <SuccessToast
        message={toastMessage}
        isVisible={showToast}
        onHide={() => setShowToast(false)}
      />
    </div>
  );
}