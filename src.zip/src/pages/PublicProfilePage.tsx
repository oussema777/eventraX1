import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Share2,
  Edit2,
  Linkedin,
  Twitter,
  Globe,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Building2,
  GraduationCap,
  Award,
  Target,
  Check
} from 'lucide-react';
import { useProfile } from '../hooks/useProfile';
import NavbarLoggedIn from '../components/navigation/NavbarLoggedIn';
import NavbarLoggedOut from '../components/navigation/NavbarLoggedOut';
import { useAuth } from '../contexts/AuthContext';

export default function PublicProfilePage() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const { profile, isLoading, error } = useProfile(userId);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0B2641] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0684F5]"></div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-[#0B2641] flex flex-col items-center justify-center text-white p-4">
        <h2 className="text-2xl font-bold mb-4">Profile Not Found</h2>
        <p className="text-gray-400 mb-8 text-center max-w-md">
          The profile you are looking for does not exist or has been set to private.
        </p>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 bg-[#0684F5] rounded-lg font-semibold"
        >
          Return Home
        </button>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === userId;
  const fullName = profile.full_name || 'Eventra User';
  const avatarUrl =
    profile.avatar_url ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=0684F5&color=fff&size=256`;
  const skills: string[] =
    profile.b2b_profile?.skills ||
    profile.professional_data?.skills ||
    [];
  const interests: string[] =
    profile.b2b_profile?.interests ||
    profile.professional_data?.interests ||
    [];
  const topics: string[] =
    profile.b2b_profile?.topics ||
    profile.b2b_profile?.meeting_topics ||
    [];
  const industries: string[] =
    profile.b2b_profile?.industries ||
    profile.b2b_profile?.industries_of_interest ||
    [];
  const goals: string[] =
    profile.b2b_profile?.lookingFor ||
    profile.b2b_profile?.meeting_goals ||
    [];

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#0B2641' }}>
      {currentUser ? <NavbarLoggedIn /> : <NavbarLoggedOut />}

      <main style={{ paddingTop: '96px', paddingBottom: '80px', paddingLeft: '24px', paddingRight: '24px' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div className="flex items-center justify-between" style={{ marginBottom: '24px' }}>
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 transition-colors"
              style={{ color: '#94A3B8' }}
              onMouseEnter={(e) => e.currentTarget.style.color = '#FFFFFF'}
              onMouseLeave={(e) => e.currentTarget.style.color = '#94A3B8'}
            >
              <ArrowLeft size={20} />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-3">
              <button
                className="p-2.5 rounded-lg transition-colors"
                style={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  color: '#FFFFFF',
                  border: '1px solid rgba(255,255,255,0.2)'
                }}
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(window.location.href);
                  } catch (_err) {
                    // no-op
                  }
                }}
              >
                <Share2 size={18} />
              </button>
              {isOwnProfile && (
                <button
                  onClick={() => navigate('/my-profile')}
                  className="px-5 py-2.5 rounded-lg transition-colors flex items-center gap-2"
                  style={{
                    backgroundColor: '#0684F5',
                    color: '#FFFFFF',
                    fontSize: '14px',
                    fontWeight: 600
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0570D6'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0684F5'}
                >
                  <Edit2 size={18} />
                  Edit Profile
                </button>
              )}
            </div>
          </div>

          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: '16px',
              overflow: 'hidden'
            }}
          >
            {/* Cover & Avatar */}
            <div style={{ position: 'relative' }}>
              <div
                style={{
                  height: '220px',
                  background: 'linear-gradient(135deg, #0684F5 0%, #4A7C6D 100%)'
                }}
              />
              <div style={{ position: 'absolute', bottom: '-60px', left: '40px' }}>
                <img
                  src={avatarUrl}
                  alt={fullName}
                  style={{
                    width: '120px',
                    height: '120px',
                    borderRadius: '50%',
                    border: '4px solid #FFFFFF',
                    objectFit: 'cover'
                  }}
                />
              </div>
            </div>

            <div style={{ padding: '80px 40px 40px' }}>
              <h2 style={{ fontSize: '28px', fontWeight: 600, color: '#1F2937', marginBottom: '8px' }}>
                {fullName}
              </h2>
              {profile.job_title && (
                <p style={{ fontSize: '16px', color: '#6B7280', marginBottom: '4px' }}>
                  {profile.job_title}
                </p>
              )}
              {profile.company && (
                <p style={{ fontSize: '16px', color: '#6B7280', marginBottom: '24px' }}>
                  {profile.company}
                </p>
              )}

              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                  About
                </h3>
                <p style={{ fontSize: '15px', color: '#4B5563', lineHeight: '1.6' }}>
                  {profile.bio || 'No biography provided.'}
                </p>
              </div>

              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                  Skills & Expertise
                </h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {skills.length > 0 ? (
                    skills.map((skill) => (
                      <div
                        key={skill}
                        style={{
                          padding: '6px 14px',
                          backgroundColor: '#E0F2FE',
                          color: '#0284C7',
                          borderRadius: '16px',
                          fontSize: '13px',
                          fontWeight: 500
                        }}
                      >
                        {skill}
                      </div>
                    ))
                  ) : (
                    <span style={{ fontSize: '14px', color: '#9CA3AF' }}>No skills listed.</span>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                  Professional Interests
                </h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {interests.length > 0 ? (
                    interests.map((interest) => (
                      <div
                        key={interest}
                        style={{
                          padding: '6px 14px',
                          backgroundColor: '#D1FAE5',
                          color: '#059669',
                          borderRadius: '16px',
                          fontSize: '13px',
                          fontWeight: 500
                        }}
                      >
                        {interest}
                      </div>
                    ))
                  ) : (
                    <span style={{ fontSize: '14px', color: '#9CA3AF' }}>No interests listed.</span>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                  Topics I Can Discuss
                </h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {topics.length > 0 ? (
                    topics.map((topic) => (
                      <div
                        key={topic}
                        style={{
                          padding: '6px 14px',
                          backgroundColor: '#DBEAFE',
                          color: '#1D4ED8',
                          borderRadius: '16px',
                          fontSize: '13px',
                          fontWeight: 500
                        }}
                      >
                        {topic}
                      </div>
                    ))
                  ) : (
                    <span style={{ fontSize: '14px', color: '#9CA3AF' }}>No topics listed.</span>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                  Industries of Interest
                </h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {industries.length > 0 ? (
                    industries.map((item) => (
                      <div
                        key={item}
                        style={{
                          padding: '6px 14px',
                          backgroundColor: '#F3E8FF',
                          color: '#7C3AED',
                          borderRadius: '16px',
                          fontSize: '13px',
                          fontWeight: 500
                        }}
                      >
                        {item}
                      </div>
                    ))
                  ) : (
                    <span style={{ fontSize: '14px', color: '#9CA3AF' }}>No industries listed.</span>
                  )}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '24px' }}>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                    <GraduationCap size={18} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    Education
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {profile.profile_education?.length ? (
                      profile.profile_education.map((edu) => (
                        <div key={edu.id} style={{ borderLeft: '2px solid #E5E7EB', paddingLeft: '12px' }}>
                          <div style={{ fontWeight: 600, color: '#1F2937' }}>{edu.degree}</div>
                          <div style={{ fontSize: '13px', color: '#6B7280' }}>{edu.institution}</div>
                          <div style={{ fontSize: '12px', color: '#9CA3AF' }}>{edu.years}</div>
                        </div>
                      ))
                    ) : (
                      <span style={{ fontSize: '13px', color: '#9CA3AF' }}>No education listed.</span>
                    )}
                  </div>
                </div>

                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937', marginBottom: '12px' }}>
                    <Award size={18} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    Certifications
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {profile.profile_certifications?.length ? (
                      profile.profile_certifications.map((cert) => (
                        <div key={cert.id} style={{ display: 'flex', gap: '10px' }}>
                          <div
                            style={{
                              width: '32px',
                              height: '32px',
                              borderRadius: '8px',
                              backgroundColor: '#F3F4F6',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                          >
                            <Award size={16} style={{ color: '#0684F5' }} />
                          </div>
                          <div>
                            <div style={{ fontWeight: 600, color: '#1F2937', fontSize: '14px' }}>{cert.name}</div>
                            <div style={{ fontSize: '12px', color: '#6B7280' }}>
                              {cert.organization} - {cert.year}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <span style={{ fontSize: '13px', color: '#9CA3AF' }}>No certifications listed.</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
              gap: '16px',
              marginTop: '24px'
            }}
          >
            <div style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <Target size={16} style={{ color: '#0684F5' }} />
                <span style={{ fontSize: '14px', fontWeight: 600, color: '#1F2937' }}>Networking Goals</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {goals.length > 0 ? (
                  goals.map((goal) => (
                    <div key={goal} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Check size={14} style={{ color: '#10B981' }} />
                      <span style={{ fontSize: '13px', color: '#4B5563' }}>{goal}</span>
                    </div>
                  ))
                ) : (
                  <span style={{ fontSize: '13px', color: '#9CA3AF' }}>No goals listed.</span>
                )}
              </div>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <Briefcase size={16} style={{ color: '#0684F5' }} />
                <span style={{ fontSize: '14px', fontWeight: 600, color: '#1F2937' }}>Engagement</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '8px' }}>
                <div style={{ backgroundColor: '#F3F4F6', borderRadius: '10px', padding: '10px', textAlign: 'center' }}>
                  <div style={{ fontSize: '18px', fontWeight: 700, color: '#1F2937' }}>{profile.events_attended || 0}</div>
                  <div style={{ fontSize: '10px', color: '#6B7280', textTransform: 'uppercase' }}>Events</div>
                </div>
                <div style={{ backgroundColor: '#F3F4F6', borderRadius: '10px', padding: '10px', textAlign: 'center' }}>
                  <div style={{ fontSize: '18px', fontWeight: 700, color: '#1F2937' }}>{profile.connections_made || 0}</div>
                  <div style={{ fontSize: '10px', color: '#6B7280', textTransform: 'uppercase' }}>Network</div>
                </div>
              </div>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <Building2 size={16} style={{ color: '#0684F5' }} />
                <span style={{ fontSize: '14px', fontWeight: 600, color: '#1F2937' }}>Contact</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {profile.website_url && (
                  <a href={profile.website_url} target="_blank" rel="noopener noreferrer" style={{ fontSize: '13px', color: '#4B5563' }}>
                    <Globe size={14} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    {profile.website_url}
                  </a>
                )}
                {profile.email && (
                  <a href={`mailto:${profile.email}`} style={{ fontSize: '13px', color: '#4B5563' }}>
                    <Mail size={14} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    {profile.email}
                  </a>
                )}
                {profile.phone_number && (
                  <span style={{ fontSize: '13px', color: '#4B5563' }}>
                    <Phone size={14} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    {profile.phone_number}
                  </span>
                )}
                {profile.location && (
                  <span style={{ fontSize: '13px', color: '#4B5563' }}>
                    <MapPin size={14} style={{ display: 'inline', marginRight: '6px', color: '#0684F5' }} />
                    {profile.location}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: '12px',
              padding: '16px',
              marginTop: '16px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <div style={{ display: 'flex', gap: '12px' }}>
              {profile.linkedin_url && (
                <a href={profile.linkedin_url} target="_blank" rel="noopener noreferrer" style={{ color: '#0A66C2' }}>
                  <Linkedin size={20} />
                </a>
              )}
              {profile.twitter_url && (
                <a href={profile.twitter_url} target="_blank" rel="noopener noreferrer" style={{ color: '#1DA1F2' }}>
                  <Twitter size={20} />
                </a>
              )}
              {profile.website_url && (
                <a href={profile.website_url} target="_blank" rel="noopener noreferrer" style={{ color: '#0684F5' }}>
                  <Globe size={20} />
                </a>
              )}
            </div>
            <div style={{ fontSize: '12px', color: '#9CA3AF' }}>
              Member since {profile.created_at ? new Date(profile.created_at).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) : 'recently'}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
