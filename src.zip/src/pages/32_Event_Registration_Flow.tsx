import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Check,
  ChevronLeft,
  Plus,
  Minus,
  CreditCard,
  FileText,
  Calendar,
  Ticket,
  Mail,
  Download,
  ExternalLink,
  HelpCircle,
  Tag,
  Loader2
} from 'lucide-react';
import Logo from '../components/ui/Logo';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';
import { createNotification } from '../lib/notifications';

type RegistrationStep = 1 | 2 | 3 | 4;

interface TicketType {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  maxQuantity: number;
  soldOut: boolean;
  earlyBird?: boolean;
}

interface FormField {
  id: string;
  label: string;
  type: string;
  required: boolean;
  options?: string[];
  value: string;
}

export default function EventRegistrationFlow() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState<RegistrationStep>(1);
  const [showPromoCode, setShowPromoCode] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'invoice'>('card');
  const [event, setEvent] = useState<any>(null);
  const [tickets, setTickets] = useState<TicketType[]>([]);
  const [formFields, setFormFields] = useState<FormField[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (eventId) {
      fetchEventData();
    }
  }, [eventId]);

  const fetchEventData = async () => {
    try {
      setIsLoading(true);
      
      // 1. Fetch Event
      const { data: eventData, error: eventError } = await supabase
        .from('events')
        .select('*')
        .eq('id', eventId)
        .single();

      if (eventError) throw eventError;
      setEvent(eventData);

      // 2. Fetch Tickets
      const { data: ticketData } = await supabase
        .from('event_tickets')
        .select('*')
        .eq('event_id', eventId)
        .eq('status', 'active');
      
      setTickets((ticketData || []).map(t => ({
        id: t.id,
        name: t.name,
        description: t.description || '',
        price: parseFloat(t.price),
        quantity: 0,
        maxQuantity: t.quantity_total || 10,
        soldOut: t.quantity_total ? (t.quantity_sold >= t.quantity_total) : false
      })));

      // 3. Fetch Form
      const { data: formData } = await supabase
        .from('event_forms')
        .select('*, event_form_fields(*)')
        .eq('event_id', eventId)
        .eq('status', 'active')
        .single();

      const defaultFields: FormField[] = [
        { id: 'fullName', label: 'Full Name', type: 'text', required: true, value: '' },
        { id: 'email', label: 'Email Address', type: 'email', required: true, value: '' }
      ];

      if (formData?.event_form_fields) {
        const customFields = formData.event_form_fields.map((f: any) => ({
          id: f.id,
          label: f.label,
          type: f.type,
          required: f.required,
          options: f.options,
          value: ''
        }));
        setFormFields([...defaultFields, ...customFields]);
      } else {
        setFormFields(defaultFields);
      }

    } catch (error) {
      console.error('Error fetching registration data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompleteRegistration = async () => {
    try {
      setIsSubmitting(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('You must be logged in to register');
        return;
      }

      // Find the selected ticket (assuming one for now for simplicity)
      const selectedTicket = tickets.find(t => t.quantity > 0);
      if (!selectedTicket) return;

      const responses: Record<string, any> = {};
      formFields.forEach(f => {
        responses[f.label] = f.value;
      });

      const { error: regError } = await supabase.from('event_attendees').insert([{
        event_id: eventId,
        profile_id: user.id,
        ticket_id: selectedTicket.id,
        status: 'registered',
        custom_responses: responses
      }]);

      if (regError) throw regError;

      // Update ticket sold count (approximate logic)
      await supabase.rpc('increment_ticket_sold', { tid: selectedTicket.id, qty: selectedTicket.quantity });

      try {
        if (event?.owner_id) {
          await createNotification({
            recipient_id: event.owner_id,
            actor_id: user.id,
            title: 'New event registration',
            body: `${user.email || 'An attendee'} registered for ${event.name || 'your event'}.`,
            type: 'action',
            action_url: `/event/${eventId}`
          });
        }
        await createNotification({
          recipient_id: user.id,
          actor_id: event?.owner_id || null,
          title: 'Registration confirmed',
          body: `You are registered for ${event?.name || 'this event'}.`,
          type: 'system',
          action_url: `/event/${eventId}/landing`
        });
      } catch {
        // Notifications should not block registration flow.
      }

      setCurrentStep(4);
    } catch (error: any) {
      toast.error(error.message || 'Registration failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNext = () => {
    if (currentStep === 3) {
      handleCompleteRegistration();
    } else if (currentStep < 4) {
      setCurrentStep((currentStep + 1) as RegistrationStep);
      window.scrollTo(0, 0);
    } else {
      navigate(`/event/${eventId}/landing`);
    }
  };

  // Payment state
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: ''
  });

  const updateTicketQuantity = (ticketId: string, change: number) => {
    setTickets(tickets.map(ticket => {
      if (ticket.id === ticketId) {
        const newQuantity = Math.max(0, Math.min(ticket.maxQuantity, ticket.quantity + change));
        return { ...ticket, quantity: newQuantity };
      }
      return ticket;
    }));
  };

  const updateFormField = (fieldId: string, value: string) => {
    setFormFields(formFields.map(field =>
      field.id === fieldId ? { ...field, value } : field
    ));
  };

  const calculateSubtotal = () => {
    return tickets.reduce((sum, ticket) => sum + (ticket.price * ticket.quantity), 0);
  };

  const calculateFees = () => {
    return calculateSubtotal() * 0.05; // 5% processing fee
  };

  const calculateDiscount = () => {
    return promoApplied ? 10.00 : 0;
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateFees() - calculateDiscount();
  };

  const getTotalTickets = () => {
    return tickets.reduce((sum, ticket) => sum + ticket.quantity, 0);
  };

  const applyPromoCode = () => {
    if (promoCode.toUpperCase() === 'SAVE10') {
      setPromoApplied(true);
    }
  };



  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((currentStep - 1) as RegistrationStep);
      window.scrollTo(0, 0);
    } else {
      navigate(-1);
    }
  };

  const canProceed = () => {
    if (currentStep === 1) return getTotalTickets() > 0;
    if (currentStep === 2) {
      return formFields.filter(f => f.required).every(f => f.value.trim() !== '');
    }
    if (currentStep === 3) {
      if (paymentMethod === 'card') {
        return cardDetails.number && cardDetails.expiry && cardDetails.cvc && cardDetails.name;
      }
      return true;
    }
    return true;
  };

  const steps = [
    { number: 1, label: 'Tickets' },
    { number: 2, label: 'Your Details' },
    { number: 3, label: 'Payment' },
    { number: 4, label: 'Confirmation' }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8F9FA' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50"
        style={{
          backgroundColor: '#FFFFFF',
          borderBottom: '1px solid #E5E7EB',
          height: '80px'
        }}
      >
        <div className="h-full flex items-center justify-between px-10">
          {/* Logo */}
          <div style={{ width: '150px' }}>
            <Logo />
          </div>

          {/* Progress Stepper */}
          <div className="flex items-center gap-2">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                {/* Step Circle */}
                <div className="flex flex-col items-center">
                  <div
                    className="flex items-center justify-center rounded-full transition-all"
                    style={{
                      width: '36px',
                      height: '36px',
                      backgroundColor: currentStep >= step.number ? '#0684F5' : '#E5E7EB',
                      color: currentStep >= step.number ? '#FFFFFF' : '#9CA3AF',
                      fontSize: '14px',
                      fontWeight: 600
                    }}
                  >
                    {currentStep > step.number ? (
                      <Check size={18} />
                    ) : (
                      step.number
                    )}
                  </div>
                  <span
                    className="mt-1"
                    style={{
                      fontSize: '11px',
                      fontWeight: 600,
                      color: currentStep >= step.number ? '#1A1D1F' : '#9CA3AF'
                    }}
                  >
                    {step.label}
                  </span>
                </div>

                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div
                    style={{
                      width: '60px',
                      height: '2px',
                      backgroundColor: currentStep > step.number ? '#0684F5' : '#E5E7EB',
                      margin: '0 8px',
                      marginBottom: '20px'
                    }}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Help Link */}
          <div style={{ width: '150px', textAlign: 'right' }}>
            <button
              className="flex items-center gap-2 transition-colors"
              style={{
                color: '#0684F5',
                fontSize: '14px',
                fontWeight: 600,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                marginLeft: 'auto'
              }}
              onMouseEnter={(e) => e.currentTarget.style.color = '#0570D6'}
              onMouseLeave={(e) => e.currentTarget.style.color = '#0684F5'}
            >
              <HelpCircle size={16} />
              Need Help?
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-10 px-6">
        <div
          className="mx-auto rounded-2xl p-10"
          style={{
            maxWidth: '900px',
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1), 0 1px 2px rgba(0, 0, 0, 0.06)'
          }}
        >
          {/* Step 1: Select Tickets */}
          {currentStep === 1 && (
            <div>
              <div className="mb-8">
                <h1 style={{ fontSize: '28px', fontWeight: 700, color: '#1A1D1F', marginBottom: '8px' }}>
                  Select Your Tickets
                </h1>
                <p style={{ fontSize: '15px', color: '#6F767E' }}>
                  Choose your ticket type and quantity for Global SaaS Summit 2025
                </p>
              </div>

              {/* Ticket Cards */}
              <div className="space-y-4 mb-8">
                {tickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="rounded-xl p-6 transition-all"
                    style={{
                      border: ticket.quantity > 0 ? '2px solid #0684F5' : '1px solid #E5E7EB',
                      backgroundColor: ticket.soldOut ? '#F9FAFB' : '#FFFFFF',
                      opacity: ticket.soldOut ? 0.6 : 1
                    }}
                  >
                    <div className="flex items-start justify-between gap-6">
                      {/* Left: Ticket Info */}
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#1A1D1F' }}>
                            {ticket.name}
                          </h3>
                          {ticket.earlyBird && !ticket.soldOut && (
                            <span
                              className="px-2 py-1 rounded-full"
                              style={{
                                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                color: '#10B981',
                                fontSize: '11px',
                                fontWeight: 700,
                                letterSpacing: '0.5px'
                              }}
                            >
                              EARLY BIRD
                            </span>
                          )}
                          {ticket.soldOut && (
                            <span
                              className="px-2 py-1 rounded-full"
                              style={{
                                backgroundColor: '#FEE2E2',
                                color: '#DC2626',
                                fontSize: '11px',
                                fontWeight: 700,
                                letterSpacing: '0.5px'
                              }}
                            >
                              SOLD OUT
                            </span>
                          )}
                        </div>
                        <p style={{ fontSize: '14px', color: '#6F767E', lineHeight: '1.5' }}>
                          {ticket.description}
                        </p>
                        {ticket.earlyBird && !ticket.soldOut && (
                          <p style={{ fontSize: '12px', color: '#10B981', marginTop: '8px', fontWeight: 600 }}>
                            🔥 Early bird pricing ends in 2 days!
                          </p>
                        )}
                      </div>

                      {/* Right: Price & Quantity */}
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <div style={{ fontSize: '24px', fontWeight: 700, color: '#1A1D1F' }}>
                            ${ticket.price.toFixed(2)}
                          </div>
                          <div style={{ fontSize: '12px', color: '#9CA3AF' }}>
                            USD
                          </div>
                        </div>

                        {/* Quantity Selector */}
                        {!ticket.soldOut && (
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateTicketQuantity(ticket.id, -1)}
                              disabled={ticket.quantity === 0}
                              className="rounded-lg transition-all"
                              style={{
                                width: '36px',
                                height: '36px',
                                backgroundColor: ticket.quantity === 0 ? '#F3F4F6' : '#FFFFFF',
                                border: '1px solid #E5E7EB',
                                color: ticket.quantity === 0 ? '#D1D5DB' : '#6F767E',
                                cursor: ticket.quantity === 0 ? 'not-allowed' : 'pointer'
                              }}
                              onMouseEnter={(e) => {
                                if (ticket.quantity > 0) {
                                  e.currentTarget.style.borderColor = '#0684F5';
                                  e.currentTarget.style.backgroundColor = '#F0F9FF';
                                }
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = '#E5E7EB';
                                e.currentTarget.style.backgroundColor = ticket.quantity === 0 ? '#F3F4F6' : '#FFFFFF';
                              }}
                            >
                              <Minus size={16} style={{ margin: '0 auto' }} />
                            </button>

                            <div
                              className="flex items-center justify-center"
                              style={{
                                width: '48px',
                                height: '36px',
                                fontSize: '16px',
                                fontWeight: 600,
                                color: '#1A1D1F'
                              }}
                            >
                              {ticket.quantity}
                            </div>

                            <button
                              onClick={() => updateTicketQuantity(ticket.id, 1)}
                              disabled={ticket.quantity >= ticket.maxQuantity}
                              className="rounded-lg transition-all"
                              style={{
                                width: '36px',
                                height: '36px',
                                backgroundColor: ticket.quantity >= ticket.maxQuantity ? '#F3F4F6' : '#FFFFFF',
                                border: '1px solid #E5E7EB',
                                color: ticket.quantity >= ticket.maxQuantity ? '#D1D5DB' : '#6F767E',
                                cursor: ticket.quantity >= ticket.maxQuantity ? 'not-allowed' : 'pointer'
                              }}
                              onMouseEnter={(e) => {
                                if (ticket.quantity < ticket.maxQuantity) {
                                  e.currentTarget.style.borderColor = '#0684F5';
                                  e.currentTarget.style.backgroundColor = '#F0F9FF';
                                }
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = '#E5E7EB';
                                e.currentTarget.style.backgroundColor = ticket.quantity >= ticket.maxQuantity ? '#F3F4F6' : '#FFFFFF';
                              }}
                            >
                              <Plus size={16} style={{ margin: '0 auto' }} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Summary */}
              {getTotalTickets() > 0 && (
                <div
                  className="rounded-xl p-6"
                  style={{
                    backgroundColor: '#F9FAFB',
                    border: '1px solid #E5E7EB'
                  }}
                >
                  <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F', marginBottom: '16px' }}>
                    Order Summary
                  </h3>

                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between">
                      <span style={{ fontSize: '14px', color: '#6F767E' }}>
                        Subtotal ({getTotalTickets()} {getTotalTickets() === 1 ? 'ticket' : 'tickets'})
                      </span>
                      <span style={{ fontSize: '14px', fontWeight: 600, color: '#1A1D1F' }}>
                        ${calculateSubtotal().toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span style={{ fontSize: '14px', color: '#6F767E' }}>
                        Service fees
                      </span>
                      <span style={{ fontSize: '14px', fontWeight: 600, color: '#1A1D1F' }}>
                        ${calculateFees().toFixed(2)}
                      </span>
                    </div>
                    {promoApplied && (
                      <div className="flex justify-between">
                        <span style={{ fontSize: '14px', color: '#10B981' }}>
                          Promo code discount
                        </span>
                        <span style={{ fontSize: '14px', fontWeight: 600, color: '#10B981' }}>
                          -${calculateDiscount().toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>

                  <div
                    className="pt-3 mb-4 flex justify-between"
                    style={{ borderTop: '1px solid #E5E7EB' }}
                  >
                    <span style={{ fontSize: '18px', fontWeight: 700, color: '#1A1D1F' }}>
                      Total
                    </span>
                    <span style={{ fontSize: '24px', fontWeight: 700, color: '#1A1D1F' }}>
                      ${calculateTotal().toFixed(2)} <span style={{ fontSize: '14px', fontWeight: 400, color: '#9CA3AF' }}>USD</span>
                    </span>
                  </div>

                  {/* Promo Code */}
                  {!showPromoCode ? (
                    <button
                      onClick={() => setShowPromoCode(true)}
                      className="flex items-center gap-2 transition-colors"
                      style={{
                        color: '#0684F5',
                        fontSize: '14px',
                        fontWeight: 600,
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        padding: 0
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.color = '#0570D6'}
                      onMouseLeave={(e) => e.currentTarget.style.color = '#0684F5'}
                    >
                      <Tag size={16} />
                      Have a promo code?
                    </button>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter promo code"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        disabled={promoApplied}
                        className="flex-1 px-3 py-2 rounded-lg"
                        style={{
                          border: '1px solid #E5E7EB',
                          fontSize: '14px',
                          color: '#1A1D1F'
                        }}
                      />
                      <button
                        onClick={applyPromoCode}
                        disabled={promoApplied || !promoCode}
                        className="px-4 py-2 rounded-lg transition-all"
                        style={{
                          backgroundColor: promoApplied ? '#10B981' : '#0684F5',
                          color: '#FFFFFF',
                          fontSize: '14px',
                          fontWeight: 600,
                          border: 'none',
                          cursor: promoApplied || !promoCode ? 'not-allowed' : 'pointer',
                          opacity: promoApplied || !promoCode ? 0.6 : 1
                        }}
                      >
                        {promoApplied ? 'Applied' : 'Apply'}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step 2: Attendee Information */}
          {currentStep === 2 && (
            <div>
              <div className="mb-8">
                <h1 style={{ fontSize: '28px', fontWeight: 700, color: '#1A1D1F', marginBottom: '8px' }}>
                  Your Details
                </h1>
                <p style={{ fontSize: '15px', color: '#6F767E' }}>
                  Please provide your information for event registration
                </p>
              </div>

              {/* Form */}
              <div className="space-y-6">
                {/* Personal Information Section */}
                <div>
                  <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F', marginBottom: '16px' }}>
                    Personal Information
                  </h3>
                  <div className="space-y-4">
                    {formFields.slice(0, 3).map((field) => (
                      <div key={field.id}>
                        <label
                          style={{
                            display: 'block',
                            fontSize: '14px',
                            fontWeight: 600,
                            color: '#1A1D1F',
                            marginBottom: '8px'
                          }}
                        >
                          {field.label}
                          {field.required && <span style={{ color: '#DC2626' }}> *</span>}
                        </label>
                        <input
                          type={field.type}
                          value={field.value}
                          onChange={(e) => updateFormField(field.id, e.target.value)}
                          className="w-full px-4 py-3 rounded-lg transition-all"
                          style={{
                            border: '1px solid #E5E7EB',
                            fontSize: '15px',
                            color: '#1A1D1F'
                          }}
                          onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                          onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Custom Fields Section */}
                <div>
                  <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F', marginBottom: '16px' }}>
                    Additional Information
                  </h3>
                  <div className="space-y-4">
                    {formFields.slice(3).map((field) => (
                      <div key={field.id}>
                        <label
                          style={{
                            display: 'block',
                            fontSize: '14px',
                            fontWeight: 600,
                            color: '#1A1D1F',
                            marginBottom: '8px'
                          }}
                        >
                          {field.label}
                          {field.required && <span style={{ color: '#DC2626' }}> *</span>}
                        </label>
                        
                        {field.type === 'text' && (
                          <input
                            type="text"
                            value={field.value}
                            onChange={(e) => updateFormField(field.id, e.target.value)}
                            className="w-full px-4 py-3 rounded-lg transition-all"
                            style={{
                              border: '1px solid #E5E7EB',
                              fontSize: '15px',
                              color: '#1A1D1F'
                            }}
                            onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                            onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                          />
                        )}

                        {field.type === 'select' && (
                          <select
                            value={field.value}
                            onChange={(e) => updateFormField(field.id, e.target.value)}
                            className="w-full px-4 py-3 rounded-lg transition-all"
                            style={{
                              border: '1px solid #E5E7EB',
                              fontSize: '15px',
                              color: '#1A1D1F',
                              cursor: 'pointer'
                            }}
                            onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                            onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                          >
                            {field.options?.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>
                        )}

                        {field.type === 'radio' && (
                          <div className="space-y-2">
                            {field.options?.map((option) => (
                              <label
                                key={option}
                                className="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all"
                                style={{
                                  border: field.value === option ? '2px solid #0684F5' : '1px solid #E5E7EB',
                                  backgroundColor: field.value === option ? '#F0F9FF' : '#FFFFFF'
                                }}
                              >
                                <input
                                  type="radio"
                                  name={field.id}
                                  value={option}
                                  checked={field.value === option}
                                  onChange={(e) => updateFormField(field.id, e.target.value)}
                                  style={{
                                    width: '18px',
                                    height: '18px',
                                    cursor: 'pointer',
                                    accentColor: '#0684F5'
                                  }}
                                />
                                <span style={{ fontSize: '14px', color: '#1A1D1F' }}>
                                  {option}
                                </span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Payment */}
          {currentStep === 3 && (
            <div>
              <div className="mb-8">
                <h1 style={{ fontSize: '28px', fontWeight: 700, color: '#1A1D1F', marginBottom: '8px' }}>
                  Complete Your Purchase
                </h1>
                <p style={{ fontSize: '15px', color: '#6F767E' }}>
                  Enter your payment details to complete registration
                </p>
              </div>

              <div className="grid grid-cols-3 gap-8">
                {/* Left: Payment Form */}
                <div className="col-span-2">
                  {/* Payment Method Selection */}
                  <div className="flex gap-3 mb-6">
                    <button
                      onClick={() => setPaymentMethod('card')}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all"
                      style={{
                        border: paymentMethod === 'card' ? '2px solid #0684F5' : '1px solid #E5E7EB',
                        backgroundColor: paymentMethod === 'card' ? '#F0F9FF' : '#FFFFFF',
                        color: paymentMethod === 'card' ? '#0684F5' : '#6F767E',
                        fontSize: '14px',
                        fontWeight: 600,
                        cursor: 'pointer'
                      }}
                    >
                      <CreditCard size={18} />
                      Credit Card
                    </button>
                    <button
                      onClick={() => setPaymentMethod('invoice')}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all"
                      style={{
                        border: paymentMethod === 'invoice' ? '2px solid #0684F5' : '1px solid #E5E7EB',
                        backgroundColor: paymentMethod === 'invoice' ? '#F0F9FF' : '#FFFFFF',
                        color: paymentMethod === 'invoice' ? '#0684F5' : '#6F767E',
                        fontSize: '14px',
                        fontWeight: 600,
                        cursor: 'pointer'
                      }}
                    >
                      <FileText size={18} />
                      Request Invoice
                    </button>
                  </div>

                  {/* Credit Card Form */}
                  {paymentMethod === 'card' && (
                    <div className="space-y-4">
                      {/* Card Number */}
                      <div>
                        <label
                          style={{
                            display: 'block',
                            fontSize: '14px',
                            fontWeight: 600,
                            color: '#1A1D1F',
                            marginBottom: '8px'
                          }}
                        >
                          Card Number *
                        </label>
                        <input
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          value={cardDetails.number}
                          onChange={(e) => setCardDetails({ ...cardDetails, number: e.target.value })}
                          className="w-full px-4 py-3 rounded-lg transition-all"
                          style={{
                            border: '1px solid #E5E7EB',
                            fontSize: '15px',
                            color: '#1A1D1F'
                          }}
                          onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                          onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                        />
                      </div>

                      {/* Expiry & CVC */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label
                            style={{
                              display: 'block',
                              fontSize: '14px',
                              fontWeight: 600,
                              color: '#1A1D1F',
                              marginBottom: '8px'
                            }}
                          >
                            Expiry Date *
                          </label>
                          <input
                            type="text"
                            placeholder="MM/YY"
                            value={cardDetails.expiry}
                            onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                            className="w-full px-4 py-3 rounded-lg transition-all"
                            style={{
                              border: '1px solid #E5E7EB',
                              fontSize: '15px',
                              color: '#1A1D1F'
                            }}
                            onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                            onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                          />
                        </div>
                        <div>
                          <label
                            style={{
                              display: 'block',
                              fontSize: '14px',
                              fontWeight: 600,
                              color: '#1A1D1F',
                              marginBottom: '8px'
                            }}
                          >
                            CVC *
                          </label>
                          <input
                            type="text"
                            placeholder="123"
                            value={cardDetails.cvc}
                            onChange={(e) => setCardDetails({ ...cardDetails, cvc: e.target.value })}
                            className="w-full px-4 py-3 rounded-lg transition-all"
                            style={{
                              border: '1px solid #E5E7EB',
                              fontSize: '15px',
                              color: '#1A1D1F'
                            }}
                            onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                            onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                          />
                        </div>
                      </div>

                      {/* Cardholder Name */}
                      <div>
                        <label
                          style={{
                            display: 'block',
                            fontSize: '14px',
                            fontWeight: 600,
                            color: '#1A1D1F',
                            marginBottom: '8px'
                          }}
                        >
                          Cardholder Name *
                        </label>
                        <input
                          type="text"
                          placeholder="Name on card"
                          value={cardDetails.name}
                          onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
                          className="w-full px-4 py-3 rounded-lg transition-all"
                          style={{
                            border: '1px solid #E5E7EB',
                            fontSize: '15px',
                            color: '#1A1D1F'
                          }}
                          onFocus={(e) => e.currentTarget.style.borderColor = '#0684F5'}
                          onBlur={(e) => e.currentTarget.style.borderColor = '#E5E7EB'}
                        />
                      </div>

                      {/* Security Notice */}
                      <div
                        className="flex items-start gap-3 p-4 rounded-lg"
                        style={{
                          backgroundColor: '#F0F9FF',
                          border: '1px solid #BAE6FD'
                        }}
                      >
                        <Check size={18} style={{ color: '#0284C7', flexShrink: 0, marginTop: '2px' }} />
                        <div>
                          <p style={{ fontSize: '13px', color: '#0284C7', lineHeight: '1.5' }}>
                            Your payment information is encrypted and secure. We never store your full card details.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Invoice Request */}
                  {paymentMethod === 'invoice' && (
                    <div
                      className="p-6 rounded-lg text-center"
                      style={{
                        backgroundColor: '#F9FAFB',
                        border: '1px solid #E5E7EB'
                      }}
                    >
                      <FileText size={48} style={{ color: '#9CA3AF', margin: '0 auto 16px' }} />
                      <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#1A1D1F', marginBottom: '8px' }}>
                        Invoice Payment
                      </h3>
                      <p style={{ fontSize: '14px', color: '#6F767E', lineHeight: '1.5', marginBottom: '16px' }}>
                        We'll send an invoice to your email address. Payment is due within 7 days of receipt.
                      </p>
                      <p style={{ fontSize: '13px', color: '#9CA3AF' }}>
                        Your registration will be confirmed after payment is received.
                      </p>
                    </div>
                  )}
                </div>

                {/* Right: Order Summary */}
                <div>
                  <div
                    className="rounded-xl p-6 sticky top-24"
                    style={{
                      backgroundColor: '#F9FAFB',
                      border: '1px solid #E5E7EB'
                    }}
                  >
                    <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F', marginBottom: '16px' }}>
                      Order Summary
                    </h3>

                    {/* Selected Tickets */}
                    <div className="space-y-3 mb-4 pb-4" style={{ borderBottom: '1px solid #E5E7EB' }}>
                      {tickets.filter(t => t.quantity > 0).map((ticket) => (
                        <div key={ticket.id} className="flex justify-between">
                          <span style={{ fontSize: '13px', color: '#6F767E' }}>
                            {ticket.name} (×{ticket.quantity})
                          </span>
                          <span style={{ fontSize: '13px', fontWeight: 600, color: '#1A1D1F' }}>
                            ${(ticket.price * ticket.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Pricing Breakdown */}
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span style={{ fontSize: '13px', color: '#6F767E' }}>Subtotal</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1A1D1F' }}>
                          ${calculateSubtotal().toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span style={{ fontSize: '13px', color: '#6F767E' }}>Service fees</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1A1D1F' }}>
                          ${calculateFees().toFixed(2)}
                        </span>
                      </div>
                      {promoApplied && (
                        <div className="flex justify-between">
                          <span style={{ fontSize: '13px', color: '#10B981' }}>Discount</span>
                          <span style={{ fontSize: '13px', fontWeight: 600, color: '#10B981' }}>
                            -${calculateDiscount().toFixed(2)}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Total */}
                    <div
                      className="pt-4 flex justify-between"
                      style={{ borderTop: '1px solid #E5E7EB' }}
                    >
                      <span style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F' }}>
                        Total
                      </span>
                      <span style={{ fontSize: '20px', fontWeight: 700, color: '#1A1D1F' }}>
                        ${calculateTotal().toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Confirmation */}
          {currentStep === 4 && (
            <div className="text-center py-8">
              {/* Success Icon */}
              <div
                className="mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{
                  width: '80px',
                  height: '80px',
                  backgroundColor: 'rgba(16, 185, 129, 0.1)',
                  border: '3px solid #10B981'
                }}
              >
                <Check size={48} style={{ color: '#10B981' }} />
              </div>

              {/* Title */}
              <h1 style={{ fontSize: '32px', fontWeight: 700, color: '#1A1D1F', marginBottom: '12px' }}>
                Registration Complete!
              </h1>

              {/* Message */}
              <p style={{ fontSize: '16px', color: '#6F767E', marginBottom: '32px', maxWidth: '500px', margin: '0 auto 32px' }}>
                Thank you for registering for <strong>Global SaaS Summit 2025</strong>! 
                A confirmation email has been sent to <strong>sarah.johnson@example.com</strong>.
              </p>

              {/* Ticket Info */}
              <div
                className="rounded-xl p-6 mb-8 text-left"
                style={{
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  maxWidth: '600px',
                  margin: '0 auto 32px'
                }}
              >
                <div className="flex items-start gap-4">
                  <Ticket size={24} style={{ color: '#0684F5', flexShrink: 0 }} />
                  <div className="flex-1">
                    <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1A1D1F', marginBottom: '8px' }}>
                      Your Tickets
                    </h3>
                    <div className="space-y-2">
                      {tickets.filter(t => t.quantity > 0).map((ticket) => (
                        <div key={ticket.id} style={{ fontSize: '14px', color: '#6F767E' }}>
                          {ticket.name} × {ticket.quantity}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <div style={{ fontSize: '20px', fontWeight: 700, color: '#1A1D1F' }}>
                      ${calculateTotal().toFixed(2)}
                    </div>
                    <div style={{ fontSize: '12px', color: '#9CA3AF' }}>
                      USD
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-3 max-w-md mx-auto">
                <button
                  className="flex items-center justify-center gap-2 px-6 py-4 rounded-lg transition-all"
                  style={{
                    backgroundColor: '#0684F5',
                    color: '#FFFFFF',
                    fontSize: '15px',
                    fontWeight: 600,
                    border: 'none',
                    cursor: 'pointer'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0570D6'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0684F5'}
                >
                  <Calendar size={18} />
                  Add to Calendar
                </button>

                <button
                  className="flex items-center justify-center gap-2 px-6 py-4 rounded-lg transition-all"
                  style={{
                    backgroundColor: '#FFFFFF',
                    color: '#0684F5',
                    fontSize: '15px',
                    fontWeight: 600,
                    border: '1px solid #0684F5',
                    cursor: 'pointer'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F0F9FF'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FFFFFF'}
                >
                  <Download size={18} />
                  Download Tickets
                </button>

                <button
                  onClick={() => navigate('/event/saas-summit-2024/landing')}
                  className="flex items-center justify-center gap-2 px-6 py-4 rounded-lg transition-all"
                  style={{
                    backgroundColor: '#FFFFFF',
                    color: '#6F767E',
                    fontSize: '15px',
                    fontWeight: 600,
                    border: '1px solid #E5E7EB',
                    cursor: 'pointer'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#F9FAFB';
                    e.currentTarget.style.color = '#1A1D1F';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#FFFFFF';
                    e.currentTarget.style.color = '#6F767E';
                  }}
                >
                  <ExternalLink size={18} />
                  Go to Event Page
                </button>
              </div>

              {/* Email Notice */}
              <div
                className="flex items-start gap-3 p-4 rounded-lg mt-8 text-left"
                style={{
                  backgroundColor: '#FEF3C7',
                  border: '1px solid #FDE68A',
                  maxWidth: '600px',
                  margin: '32px auto 0'
                }}
              >
                <Mail size={18} style={{ color: '#D97706', flexShrink: 0, marginTop: '2px' }} />
                <div>
                  <p style={{ fontSize: '13px', color: '#92400E', lineHeight: '1.5' }}>
                    <strong>Check your email:</strong> We've sent your tickets and event details to your inbox. 
                    Don't forget to add the event to your calendar!
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer Navigation */}
      <footer
        className="fixed bottom-0 left-0 right-0 z-40"
        style={{
          backgroundColor: '#FFFFFF',
          borderTop: '1px solid #E5E7EB',
          padding: '20px 40px'
        }}
      >
        <div
          className="flex items-center justify-between mx-auto"
          style={{ maxWidth: '900px' }}
        >
          {/* Back Button */}
          <button
            onClick={handleBack}
            className="flex items-center gap-2 px-5 py-3 rounded-lg transition-all"
            style={{
              backgroundColor: '#FFFFFF',
              color: '#6F767E',
              fontSize: '14px',
              fontWeight: 600,
              border: '1px solid #E5E7EB',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#F9FAFB';
              e.currentTarget.style.color = '#1A1D1F';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#FFFFFF';
              e.currentTarget.style.color = '#6F767E';
            }}
          >
            <ChevronLeft size={18} />
            Back
          </button>

          {/* Next/Complete Button */}
          {currentStep < 4 ? (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className="px-8 py-3 rounded-lg transition-all"
              style={{
                backgroundColor: canProceed() ? (currentStep === 3 ? '#10B981' : '#0684F5') : '#E5E7EB',
                color: canProceed() ? '#FFFFFF' : '#9CA3AF',
                fontSize: '14px',
                fontWeight: 600,
                border: 'none',
                cursor: canProceed() ? 'pointer' : 'not-allowed'
              }}
              onMouseEnter={(e) => {
                if (canProceed()) {
                  e.currentTarget.style.backgroundColor = currentStep === 3 ? '#059669' : '#0570D6';
                }
              }}
              onMouseLeave={(e) => {
                if (canProceed()) {
                  e.currentTarget.style.backgroundColor = currentStep === 3 ? '#10B981' : '#0684F5';
                }
              }}
            >
              {currentStep === 3 ? 'Complete Purchase' : 'Continue'}
            </button>
          ) : (
            <button
              onClick={() => navigate('/event/saas-summit-2024/landing')}
              className="px-8 py-3 rounded-lg transition-all"
              style={{
                backgroundColor: '#0684F5',
                color: '#FFFFFF',
                fontSize: '14px',
                fontWeight: 600,
                border: 'none',
                cursor: 'pointer'
              }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0570D6'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0684F5'}
            >
              Done
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
