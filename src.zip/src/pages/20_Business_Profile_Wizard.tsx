import BusinessProfileWizard from '../components/business/BusinessProfileWizard';

export default function BusinessProfileWizardPage() {
  return <BusinessProfileWizard />;
}
